{{- define "feature.hostMetrics.windowsHosts.allowList" }}
{{- $allowList := list }}
{{ if .Values.windowsHosts.metricsTuning.useDefaultAllowList }}
{{- $allowList = concat $allowList (list "up" "scrape_samples_scraped") (.Files.Get "default-allow-lists/windows-exporter.yaml" | fromYamlArray) -}}
{{ end }}
{{ if .Values.windowsHosts.metricsTuning.useIntegrationAllowList }}
{{- $allowList = concat $allowList (list "up" "scrape_samples_scraped") (.Files.Get "default-allow-lists/windows-exporter-integration.yaml" | fromYamlArray) -}}
{{ end }}
{{ if .Values.windowsHosts.metricsTuning.includeMetrics }}
{{- $allowList = concat $allowList (list "up" "scrape_samples_scraped") .Values.windowsHosts.metricsTuning.includeMetrics -}}
{{ end }}
{{ $allowList | uniq | toYaml }}
{{- end }}

{{- define "feature.hostMetrics.windowsHosts.alloy" }}
{{- if .Values.windowsHosts.enabled }}
{{- $source := .Values.windowsHosts.source | default "windows-exporter" }}
{{- $metricAllowList := include "feature.hostMetrics.windowsHosts.allowList" . | fromYamlArray }}
{{- $metricDenyList := .Values.windowsHosts.metricsTuning.excludeMetrics }}
{{- /* The only difference between the two sources is how the targets are discovered: an external
       Windows Exporter deployment, or an internal prometheus.exporter.windows run by Alloy. Both
       expose their targets as discovery.relabel.windows_exporter.output, which the shared scrape and
       metrics tuning below consume. */}}
{{- if eq $source "alloy" }}
{{- include "feature.hostMetrics.windowsHosts.discovery.viaAlloy" . }}
{{- else }}
{{- include "feature.hostMetrics.windowsHosts.discovery.viaWindowsExporter" . }}
{{- end }}

prometheus.scrape "windows_exporter" {
  targets  = discovery.relabel.windows_exporter.output
  job_name   = {{ .Values.windowsHosts.jobLabel | quote }}
  scrape_interval = {{ .Values.windowsHosts.scrapeInterval | default .Values.global.scrapeInterval | quote }}
  scrape_timeout = {{ .Values.windowsHosts.scrapeTimeout | default .Values.global.scrapeTimeout | quote }}
  scrape_protocols = {{ include "helper.scrapeProtocols" . }}
  scrape_classic_histograms = {{ .Values.global.scrapeClassicHistograms }}
  scrape_native_histograms = {{ .Values.global.scrapeNativeHistograms }}
  convert_classic_histograms_to_nhcb = {{ .Values.global.convertClassicHistogramsToNhcb }}
{{- if ne $source "alloy" }}
  scheme = {{ .Values.windowsHosts.scheme | quote }}
  {{- if .Values.windowsHosts.bearerTokenFile }}
  bearer_token_file = {{ .Values.windowsHosts.bearerTokenFile | quote }}
  {{- end }}
  tls_config {
    insecure_skip_verify = true
  }

  clustering {
    enabled = true
  }
{{- end }}
{{- if or $metricAllowList $metricDenyList .Values.windowsHosts.extraMetricProcessingRules }}
  forward_to = [prometheus.relabel.windows_exporter.receiver]
} // prometheus.scrape "windows_exporter"

prometheus.relabel "windows_exporter" {
  max_cache_size = {{ .Values.windowsHosts.maxCacheSize | default .Values.global.maxCacheSize | int }}
{{- if $metricAllowList }}
  rule {
    source_labels = ["__name__"]
    regex = {{ $metricAllowList | join "|" | quote }}
    action = "keep"
  }
{{- end }}
{{- if $metricDenyList }}
  rule {
    source_labels = ["__name__"]
    regex = {{ $metricDenyList | join "|" | quote }}
    action = "drop"
  }
{{- end }}
{{- if .Values.windowsHosts.extraMetricProcessingRules }}
  {{- .Values.windowsHosts.extraMetricProcessingRules | nindent 2 }}
{{- end }}
  forward_to = argument.metrics_destinations.value
} // prometheus.relabel "windows_exporter"
{{- else }}
  forward_to = argument.metrics_destinations.value
} // prometheus.scrape "windows_exporter"
{{- end }}
{{- end }}
{{- end }}

{{- define "feature.hostMetrics.windowsHosts.discovery.viaWindowsExporter" }}
{{- $namespace := .Values.windowsHosts.namespace }}
{{- if dig "windows-exporter" "deploy" false (.telemetryServices | default dict) }}
  {{- $namespace = (dig "windows-exporter" "namespaceOverride" false (.telemetryServices | default dict) | default .Release.Namespace) }}
{{- end }}
{{- $labelSelectors := list }}
{{- if .Values.windowsHosts.labelMatchers }}
  {{- range $label, $value := .Values.windowsHosts.labelMatchers }}
    {{- $labelSelectors = append $labelSelectors (printf "%s=%s" $label $value) }}
  {{- end }}
{{- else if dig "windows-exporter" "deploy" false (.telemetryServices | default dict) }}
  {{- $labelSelectors = append $labelSelectors (printf "release=%s" .Release.Name) }}
  {{- $labelSelectors = append $labelSelectors "app.kubernetes.io/name=windows-exporter" }}
{{- end }}

// Windows hosts via Windows Exporter
discovery.kubernetes "windows_exporter_pods" {
  role = "pod"
  selectors {
    role = "pod"
    label = {{ $labelSelectors | join "," | quote }}
  }
{{- if $namespace }}
  namespaces {
    names = [{{ $namespace | quote }}]
  }
{{- end }}
{{- include "feature.hostMetrics.attachNodeMetadata" . | trim | nindent 2 }}
} // discovery.kubernetes "windows_exporter_pods"

discovery.relabel "windows_exporter" {
  targets = discovery.kubernetes.windows_exporter_pods.targets

  // keep only the specified metrics port name, and pods that are Running and ready
  rule {
    source_labels = [
      "__meta_kubernetes_pod_container_init",
      "__meta_kubernetes_pod_phase",
      "__meta_kubernetes_pod_ready",
    ]
    separator = "@"
    regex = "false@Running@true"
    action = "keep"
  }

  // Set the instance label to the node name
  rule {
    source_labels = ["__meta_kubernetes_pod_node_name"]
    target_label = "instance"
  }

{{- include "feature.hostMetrics.nodeDiscoveryRules" . | trim | nindent 2 }}
{{- if .Values.windowsHosts.extraDiscoveryRules }}
  {{- .Values.windowsHosts.extraDiscoveryRules | nindent 2 }}
{{- end }}
} // discovery.relabel "windows_exporter"
{{- end }}

{{- define "feature.hostMetrics.windowsHosts.discovery.viaAlloy" }}

// Windows hosts via Alloy (prometheus.exporter.windows)
prometheus.exporter.windows "windows_exporter" { }

discovery.relabel "windows_exporter" {
  targets = prometheus.exporter.windows.windows_exporter.targets

  // Set the instance label to the node name
  rule {
    action = "replace"
    target_label = "instance"
    replacement = sys.env("NODE_NAME")
  }

  // Override the job label set by prometheus.exporter.windows to match the Windows Exporter source
  rule {
    action = "replace"
    target_label = "job"
    replacement = {{ .Values.windowsHosts.jobLabel | quote }}
  }

  // set a source label
  rule {
    action = "replace"
    replacement = "kubernetes"
    target_label = "source"
  }
{{- if .Values.windowsHosts.extraDiscoveryRules }}
  {{- .Values.windowsHosts.extraDiscoveryRules | nindent 2 }}
{{- end }}
} // discovery.relabel "windows_exporter"
{{- end }}
