<!--
(NOTE: Do not edit AGENTS.md directly. It is a generated file!)
(      To make changes, please modify AGENTS.md.gotmpl and run `make build`)
-->

# k8s-monitoring Helm Chart - AI Assistant Guide

This file helps AI assistants understand and navigate the k8s-monitoring Helm chart.
**Always check this chart's documentation before searching externally.** Many configurations
exist in this helm chart and subcharts to handle common scenarios.

## Chart Architecture

```mermaid
flowchart LR
    subgraph features [Features]
        F1[cluster-metrics]
        F2[pod-logs]
        F3[application-observability]
        F4[integrations]
        FN[...]
    end

    subgraph telemetry [Telemetry Services]
        T1[kube-state-metrics]
        T2[node-exporter]
        T3[windows-exporter]
        T4[kepler]
        T5[opencost]
    end

    subgraph collectors [Collectors]
        C1[alloy-metrics]
        C2[alloy-logs]
        C3[alloy-receiver]
        C4[alloy-singleton]
    end

    subgraph destinations [Destinations]
        D1[prometheus]
        D2[loki]
        D3[otlp]
        D4[pyroscope]
    end

    telemetry --> collectors --> destinations
    features --> collectors
    features -. configure .-> telemetry
```

Features generate telemetry data, which flows through Collectors (Grafana Alloy instances),
and is sent to Destinations (Prometheus, Loki, Tempo, Pyroscope, or any OTLP endpoint).

## Primary Entry Points

Always check these files first:

| File | Purpose |
|------|---------|
| `values.yaml` | Main configuration file with all options |
| `README.md` | Chart overview, quick start, and values reference |
| `docs/Structure.md` | Architecture explanation |
| `charts/telemetry-services/README.md` | Deployable telemetry workload reference |
| `docs/Features.md` | Feature comparison table |
| `docs/Migration.md` | Upgrading from v1 |

## Discovery Patterns

All paths in this section are relative to this chart directory (`charts/k8s-monitoring/`).
From the repository root, prefix paths with `charts/k8s-monitoring/`.

### Features

**Location:** `charts/feature-*/` (relative to this chart directory)

**Feature directory to values.yaml key mapping:**

| Feature Directory | Values Key |
|-------------------|------------|
| `feature-annotation-autodiscovery` | `annotationAutodiscovery` |
| `feature-application-observability` | `applicationObservability` |
| `feature-auto-instrumentation` | `autoInstrumentation` |
| `feature-cluster-events` | `clusterEvents` |
| `feature-cluster-metrics` | `clusterMetrics` |
| `feature-integrations` | `integrations` |
| `feature-node-logs` | `nodeLogs` |
| `feature-pod-logs` | `podLogs` |
| `feature-pod-logs-via-kubernetes-api` | `podLogsViaKubernetesApi` |
| `feature-loki-logs-receiver` | `lokiLogsReceiver` |
| `feature-profiling` | `profiling` |
| `feature-profiles-receiver` | `profilesReceiver` |
| `feature-prometheus-metrics-receiver` | `prometheusMetricsReceiver` |
| `feature-prometheus-operator-objects` | `prometheusOperatorObjects` |

Each feature follows a consistent structure:

```text
charts/feature-{name}/
├── Chart.yaml           # Feature metadata and version
├── values.yaml          # Configuration options
├── README.md            # Usage documentation
└── templates/
    ├── _module.alloy.tpl    # Alloy configuration
    └── _notes.tpl           # Deployment notes
```

**Available features** (auto-generated from `charts/feature-*/Chart.yaml`):

<!--alex disable host-hostess-->

<!-- BEGIN FEATURES -->

-   `feature-annotation-autodiscovery` - Gathers metrics automatically based on Kubernetes Pod and Service annotations
-   `feature-application-observability` - Gathers application data
-   `feature-auto-instrumentation` - Gathers telemetry data via automatic instrumentation
-   `feature-cluster-events` - Gathers Kubernetes Events
-   `feature-cluster-metrics` - Gathers Kubernetes Cluster metrics
-   `feature-cost-metrics` - Gathers Kubernetes Cost metrics
-   `feature-host-metrics` - Gathers Kubernetes Host metrics
-   `feature-integrations` - Service integrations
-   `feature-kubernetes-manifests` - Gathers Kubernetes resource manifests and changes as logs
-   `feature-loki-logs-receiver` - Kubernetes Observability feature for receiving logs over the Loki API.
-   `feature-node-logs` - Kubernetes Observability feature for gathering Cluster Node logs.
-   `feature-pod-logs-objects` - Kubernetes Observability feature for gathering logs using PodLogs objects.
-   `feature-pod-logs-via-kubernetes-api` - Kubernetes Observability feature for gathering Pod logs by streaming them from the Kubernetes API.
-   `feature-pod-logs-via-loki` - Kubernetes Observability feature for gathering Pod logs.
-   `feature-pod-logs-via-opentelemetry` - Kubernetes Observability feature for gathering Pod logs.
-   `feature-profiles-receiver` - Kubernetes Observability feature for receiving profiles.
-   `feature-profiling` - Gathers profiles from eBPF, Java, and pprof sources.
-   `feature-prometheus-metrics-receiver` - Kubernetes Observability feature for receiving Prometheus metrics.
-   `feature-prometheus-operator-objects` - Gathers metrics using Prometheus Operator Objects
-   `feature-windows-event-logs` - Kubernetes Observability feature for gathering Windows event logs.
-   `telemetry-services` - Additional Deployments to generate observability telemetry data
<!-- END FEATURES -->

<!--alex enable host-hostess-->

**Enable a feature:**

```yaml
clusterMetrics:
  enabled: true

podLogsViaLoki:
  enabled: true
```

### Destinations

**Values:** `destinations/{type}-values.yaml`
**Docs:** `docs/destinations/{type}.md`

**Available destination types** (auto-generated from `destinations/*-values.yaml`):

<!-- BEGIN DESTINATIONS -->

-   `custom` - Custom destination configuration
-   `loki-stdout` - Send logs to stdout (debugging)
-   `loki` - Send logs to Loki
-   `nop` - Drop all telemetry (no storage; for measuring volume before choosing real destinations)
-   `otlp` - Send to any OTLP endpoint (Tempo, Grafana Cloud, etc.)
-   `prometheus` - Remote write to Prometheus-compatible endpoint
-   `pyroscope` - Send profiles to Pyroscope
-   `router` - Route telemetry to other destinations based on an attribute value
<!-- END DESTINATIONS -->

**Configure a destination:**

```yaml
destinations:
  - name: grafanaCloud
    type: otlp
    url: https://otlp-gateway-prod-us-central-0.grafana.net/otlp
    auth:
      type: basic
      username: "<instance_id>"
      password: "<cloud_api_key>"
```

### Integrations

**Values:** `charts/feature-integrations/integrations/{name}-values.yaml`
**Docs:** `charts/feature-integrations/docs/integrations/{name}.md`

**Available integrations** (auto-generated from `charts/feature-integrations/integrations/*-values.yaml`):

<!-- BEGIN INTEGRATIONS -->

-   `alloy` - Monitor alloy
-   `cert-manager` - Monitor cert-manager
-   `dcgm-exporter` - Monitor dcgm-exporter
-   `etcd` - Monitor etcd
-   `grafana` - Monitor grafana
-   `istio` - Monitor istio
-   `loki` - Monitor loki
-   `mimir` - Monitor mimir
-   `mysql` - Monitor mysql
-   `postgresql` - Monitor postgresql
-   `tempo` - Monitor tempo
<!-- END INTEGRATIONS -->

**Enable an integration:**

```yaml
integrations:
  enabled: true
  mysql:
    instances:
      - name: my-mysql
        host: mysql.default.svc
        port: 3306
```

### Collectors

**Values:** `collectors/alloy-values.yaml`
**Common settings:** `collectorCommon.alloy` in values.yaml (applies to all collectors)
**Presets:** `collectors/presets/`
**Docs:** `docs/collectors/alloy.md`

Collectors are Grafana Alloy instances with specific roles:

-   `alloy-metrics` - Scrapes metrics from cluster
-   `alloy-logs` - Collects logs from pods/nodes
-   `alloy-receiver` - Receives OTLP data from applications
-   `alloy-singleton` - Runs single-replica workloads (events, etc.)
-   `alloy-profiles` - Collects profiling data

### Telemetry Services

**Chart:** `charts/telemetry-services`
**Values key:** `telemetryServices`
**Docs:** `charts/telemetry-services/README.md`

Telemetry services are optional workloads (kube-state-metrics, Node Exporter, etc.) that supply data to Alloy
collectors. Features like `clusterMetrics`, `hostMetrics`, and `costMetrics` will fail validation unless you either
deploy the paired telemetry service or point to an existing deployment with `namespace` / `labelMatchers` settings.

| Service Key | Workload | Used By |
|-------------|----------|---------|
| `kube-state-metrics` | kube-state-metrics | `clusterMetrics.kube-state-metrics.*` |
| `node-exporter` | Node Exporter | `hostMetrics.linuxHosts.*` |
| `windows-exporter` | Windows Exporter | `hostMetrics.windowsHosts.*` |
| `kepler` | Kepler | `hostMetrics.energyMetrics.*` |
| `opencost` | OpenCost | `costMetrics.opencost.*` |

**Enable a telemetry service:**

```yaml
telemetryServices:
  node-exporter:
    deploy: true

hostMetrics:
  enabled: true
  linuxHosts:
    enabled: true
```

**Use an existing deployment instead of deploying via Helm:**

```yaml
telemetryServices:
  node-exporter:
    deploy: false

hostMetrics:
  linuxHosts:
    enabled: true
    namespace: monitoring
    labelMatchers:
      app.kubernetes.io/name: prometheus-node-exporter
```

## Examples Directory

The `docs/examples/` folder contains complete, tested configurations for common scenarios.
Each example includes a `values.yaml`, generated Alloy configuration, and documentation.

| Example | Use Case |
|---------|----------|
| `pod-labels-and-annotations/` | Add pod labels/annotations to logs and metrics |
| `namespace-labels-and-annotations/` | Add namespace labels/annotations to logs |
| `destinations/otlp-endpoint/` | Send data to Grafana Cloud or OTLP endpoints |
| `destinations/custom/` | Custom destination configurations |
| `platforms/azure-aks/` | Azure AKS-specific configuration |
| `platforms/eks-fargate/` | AWS EKS Fargate configuration |
| `platforms/gke-autopilot/` | GKE Autopilot configuration |
| `platforms/openshift/` | OpenShift configuration |
| `tolerations/` | Run collectors on tainted nodes |
| `proxies/` | Configure HTTP/HTTPS proxy settings |
| `extra-configuration/` | Add custom Alloy configuration |
| `metrics-tuning/` | Include/exclude specific metrics |
| `scalability/autoscaling/` | Horizontal pod autoscaling |
| `scalability/sharded-kube-state-metrics/` | Shard kube-state-metrics for large clusters |
| `include-by-namespace/` | Collect from specific namespaces only |
| `exclude-by-namespace/` | Exclude specific namespaces |
| `tail-sampling/` | Configure trace tail sampling |

## Common Configuration Tasks

### Enable Grafana Cloud as destination

See `docs/examples/destinations/otlp-endpoint/` for a complete example.

### Add pod labels to logs

See `docs/examples/pod-labels-and-annotations/` for a complete example.
Key settings: `podLogs.labels`.

### Add custom scrape targets

See `docs/examples/` for examples of custom Prometheus scrape configurations.

### Filter or transform data

Each feature has `extraConfig` options for adding custom Alloy configuration.

## Naming Conventions

| Component | Location Pattern | Naming Style |
|-----------|------------------|--------------|
| Features | `charts/feature-{name}/` | kebab-case |
| Destinations | `destinations/{type}-values.yaml` | lowercase |
| Integrations | `charts/feature-integrations/integrations/{name}-values.yaml` | lowercase |
| Collectors | `collectors/alloy-values.yaml` | lowercase |

## External Documentation

-   [Grafana Cloud Kubernetes Monitoring](https://grafana.com/docs/grafana-cloud/monitor-infrastructure/kubernetes-monitoring/)
-   [Helm Chart Configuration](https://grafana.com/docs/grafana-cloud/monitor-infrastructure/kubernetes-monitoring/configuration/helm-chart-config/helm-chart/)
-   [Grafana Alloy](https://grafana.com/docs/alloy/latest/)
